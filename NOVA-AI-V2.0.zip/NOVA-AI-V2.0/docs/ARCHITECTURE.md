# Architecture Notes

This document is the home for architecture decision records (ADRs) and
diagrams as NOVA-AI-V2.0 grows.

## Current State

The repository currently implements only the **structural skeleton** of a
clean-architecture backend plus a placeholder frontend and plugin system.
No business logic, database, AI provider, or speech recognition integration
has been implemented.

## Layering (backend)

```
infrastructure  →  api  →  core  →  domain
```

Dependencies always point inward, toward `domain/`. See the root
`README.md` for the full folder-by-folder breakdown.

## Open Decisions (not yet made)

- Backend framework (Express / Fastify / NestJS / other)
- Database technology
- Frontend framework (React / Vue / Svelte / other)
- AI provider integration details (Gemini)
- Speech recognition provider
- Authentication strategy
- Deployment target
