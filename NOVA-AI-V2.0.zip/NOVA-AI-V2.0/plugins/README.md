# Plugins

This directory is reserved for future extensibility modules — self-contained
add-ons that extend NOVA-AI-V2.0 without modifying core backend/frontend code.

## Intent

- Each plugin will live in its own subfolder (see `example-plugin/`).
- A plugin loader (not yet implemented) will discover and register plugins
  from this directory at application startup.
- Plugins should depend only on stable interfaces exposed by the core
  application — never reach into internal backend/frontend implementation
  details directly.

## Status

NOT IMPLEMENTED YET. No plugin loader or plugin API contract exists yet.
