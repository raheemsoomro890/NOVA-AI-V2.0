/**
 * Example Plugin — Placeholder
 * -----------------------------------------------------------------------
 * Demonstrates the expected shape of a future plugin: a manifest file
 * (plugin.manifest.json) plus an entry file exporting the plugin's hooks.
 *
 * NOT IMPLEMENTED YET — no plugin loader exists to consume this.
 * -----------------------------------------------------------------------
 */
