/**
 * Configuration Loader
 * -----------------------------------------------------------------------
 * Will be responsible for reading and validating process.env (populated
 * from .env, see .env.example at the repo root) and exposing a single,
 * typed configuration object to the rest of the application.
 *
 * NOT IMPLEMENTED YET — no environment variables are read.
 * -----------------------------------------------------------------------
 */
