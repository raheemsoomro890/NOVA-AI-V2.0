/**
 * API Routes — Aggregator
 * -----------------------------------------------------------------------
 * This module will collect and mount all individual route files
 * (e.g. userRoutes.js, authRoutes.js) onto a single Express/Fastify
 * router, then export that router for src/index.js to mount under
 * the API_PREFIX defined in .env.
 *
 * NOT IMPLEMENTED YET — no routes are defined.
 * -----------------------------------------------------------------------
 */
