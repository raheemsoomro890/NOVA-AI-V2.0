# NOVA-AI-V2.0

> Production-grade project foundation. Clean architecture. Scalable by design.

**Status:** 🏗️ Foundation stage — structure only. No business logic, UI, AI
integration, or speech recognition has been implemented yet. This repository
currently defines *where things will live* and *how the layers are allowed to
depend on each other*, so future work has a stable skeleton to build inside.

---

## 1. Project Structure

```
NOVA-AI-V2.0/
├── backend/                 # Server-side application (clean architecture)
│   ├── src/
│   │   ├── api/              # Presentation layer — HTTP surface
│   │   │   ├── routes/
│   │   │   ├── controllers/
│   │   │   ├── middlewares/
│   │   │   └── validators/
│   │   ├── core/              # Application layer — orchestration, config
│   │   │   ├── config/
│   │   │   ├── services/
│   │   │   ├── utils/
│   │   │   └── constants/
│   │   ├── domain/            # Domain layer — entities & business rules
│   │   │   ├── entities/
│   │   │   ├── repositories/  # Interfaces/contracts only
│   │   │   └── usecases/
│   │   └── infrastructure/    # Infra layer — DB, external APIs, logging
│   │       ├── database/
│   │       ├── external/
│   │       └── logging/
│   └── tests/
│       ├── unit/
│       └── integration/
│
├── frontend/                 # Client application
│   ├── src/
│   │   ├── assets/
│   │   ├── components/
│   │   ├── pages/
│   │   ├── hooks/
│   │   ├── services/
│   │   ├── context/
│   │   ├── styles/
│   │   └── utils/
│   └── public/
│
├── plugins/                  # Future extensibility — third-party/plugin modules
│   └── example-plugin/
│
├── assets/                   # Shared, project-level static assets
│   ├── images/
│   ├── audio/
│   ├── icons/
│   └── fonts/
│
├── docs/                     # Architecture decisions, specs, diagrams
├── scripts/                  # Repo-level automation scripts
├── .github/workflows/        # CI/CD pipelines
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## 2. Architectural Principles

This project follows **clean architecture**, with dependencies pointing
inward only:

```
infrastructure  →  api  →  core  →  domain
```

- **`domain/`** has zero external dependencies. It defines entities and
  repository *interfaces* — the business rules in their purest form.
- **`core/`** (application layer) orchestrates use cases and depends only on
  `domain/`.
- **`api/`** (presentation layer) exposes HTTP routes/controllers and
  depends on `core/`, never the other way around.
- **`infrastructure/`** implements the interfaces defined in `domain/`
  (databases, external services, logging) and is swappable without touching
  business logic.

This separation means the AI provider, database, or delivery mechanism can
all be replaced later without rewriting the domain logic.

## 3. Prerequisites

- Node.js `>= 18`
- npm `>= 9`

## 4. Getting Started

```bash
# 1. Clone and install
git clone <repo-url>
cd NOVA-AI-V2.0
npm install

# 2. Configure environment
cp .env.example .env
# then fill in real values in .env

# 3. Run (once implementations exist)
npm run dev:backend
npm run dev:frontend
```

## 5. Workspaces

This repo is configured as an npm workspace with two packages:

| Workspace  | Path        | Purpose                          |
|------------|-------------|-----------------------------------|
| `backend`  | `/backend`  | API server, clean-architecture layers |
| `frontend` | `/frontend` | Client application                |

## 6. Roadmap (not yet implemented)

- [ ] Business logic in `domain/usecases`
- [ ] Gemini integration (`infrastructure/external`)
- [ ] Speech recognition module
- [ ] Frontend UI implementation
- [ ] Plugin loader for `plugins/`
- [ ] CI/CD pipeline in `.github/workflows`

## 7. Contributing

See [`docs/`](./docs) for architecture notes as they're added. Until a
`CONTRIBUTING.md` exists, keep changes scoped to one layer at a time and
respect the dependency direction described in Section 2.

## 8. License

Unlicensed / private — update once a license is chosen.
